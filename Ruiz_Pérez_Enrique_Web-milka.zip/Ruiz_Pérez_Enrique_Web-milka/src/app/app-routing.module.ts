import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InicioComponent } from './inicio/inicio.component';
import { NovedadesComponent } from './novedades/novedades.component';
import { SobreMilkaComponent } from './sobre-milka/sobre-milka.component';
import { ProductosComponent } from './productos/productos.component';
import { NuevoMilkaComponent } from './nuevo-milka/nuevo-milka.component';

const routes: Routes = [
  { path: '', component: InicioComponent }, // Página principal
  { path: 'novedades', component: NovedadesComponent },
  { path: 'sobre-milka', component: SobreMilkaComponent },
  { path: 'productos', redirectTo: '' }, // Redirección a inicio
  { path: 'nuevo-milka', redirectTo: '' }, // Redirección a inicio
  { path: '**', redirectTo: '' }, // Redirección en caso de ruta no encontrada
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled', // Activa el scroll al inicio
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}