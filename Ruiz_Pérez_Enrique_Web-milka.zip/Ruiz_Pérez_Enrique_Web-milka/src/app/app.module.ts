import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module'; // Importa el módulo de rutas
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { InicioComponent } from './inicio/inicio.component';
import { NovedadesComponent } from './novedades/novedades.component';
import { SobreMilkaComponent } from './sobre-milka/sobre-milka.component';
import { ProductosComponent } from './productos/productos.component';
import { NuevoMilkaComponent } from './nuevo-milka/nuevo-milka.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    InicioComponent,
    NovedadesComponent,
    SobreMilkaComponent,
    ProductosComponent,
    NuevoMilkaComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, // Asegúrate de incluir el módulo aquí
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}