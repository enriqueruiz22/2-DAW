import { Component } from '@angular/core';

@Component({
  selector: 'app-nuevo-milka',
  templateUrl: './nuevo-milka.component.html',
  styleUrls: ['./nuevo-milka.component.scss']
})
export class NuevoMilkaComponent {

}
