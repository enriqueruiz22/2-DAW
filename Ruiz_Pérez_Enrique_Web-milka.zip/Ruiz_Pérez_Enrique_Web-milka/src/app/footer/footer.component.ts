import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  // Datos dinámicos para las categorías del footer
  categories = [
    {
      title: 'PRODUCTOS',
      items: ['Nuevo', 'Tabletas de chocolate', 'Galletas y bizcochitos', 'Bombones', 'Barritas'],
    },
    {
      title: 'NOVEDAD',
      items: ['El sabor de la ternura', 'Milka MMMax Almendras Enteras Tostadas'],
    },
    {
      title: 'SOBRE MILKA',
      items: ['Historia', 'Sabor', 'Nuestro compromiso', 'Fabricación de chocolate'],
    },
  ];

  // Enlaces legales
  legalLinks = [
    'CONDICIONES DE USO',
    'PUBLICIDAD EN LÍNEA BASADA EN EL USO',
    'POLÍTICA DE PROTECCIÓN DE DATOS',
    'POLÍTICA DE COOKIES',
    'CONTACTO',
  ];

  // Información adicional
  copyright = '2024 MONDELEZ ESPANA COMMERCIAL, S.L - TODOS LOS DERECHOS RESERVADOS';
}