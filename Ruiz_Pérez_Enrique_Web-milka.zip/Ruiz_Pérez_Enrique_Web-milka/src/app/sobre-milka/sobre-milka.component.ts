import { Component } from '@angular/core';

@Component({
  selector: 'app-sobre-milka',
  templateUrl: './sobre-milka.component.html',
  styleUrls: ['./sobre-milka.component.scss']
})
export class SobreMilkaComponent {

}
