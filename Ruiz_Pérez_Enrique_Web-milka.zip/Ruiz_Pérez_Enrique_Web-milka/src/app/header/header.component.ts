import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  // Propiedad para controlar el estado del header
  isScrolled = false;

  // Opciones del menú de navegación
  navigationLinks = [
    { label: 'NOVEDADES', route: '/novedades' },
    { label: 'SOBRE MILKA', route: '/sobre-milka' },
    { label: 'PRODUCTOS', route: '/' }, // Redirige a la página de inicio
    { label: 'NUEVO MILKA', route: '/' }, // Redirige a la página de inicio
  ];

  // Escucha el evento de scroll de la ventana
  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    this.isScrolled = scrollTop > 0; // Cambia el estado dependiendo de la posición de scroll
  }
}