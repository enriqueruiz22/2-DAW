import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SobreMilkaComponent } from './sobre-milka.component';

describe('SobreMilkaComponent', () => {
  let component: SobreMilkaComponent;
  let fixture: ComponentFixture<SobreMilkaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SobreMilkaComponent]
    });
    fixture = TestBed.createComponent(SobreMilkaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
