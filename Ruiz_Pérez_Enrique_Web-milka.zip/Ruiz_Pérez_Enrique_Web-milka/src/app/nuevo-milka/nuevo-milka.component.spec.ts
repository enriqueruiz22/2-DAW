import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevoMilkaComponent } from './nuevo-milka.component';

describe('NuevoMilkaComponent', () => {
  let component: NuevoMilkaComponent;
  let fixture: ComponentFixture<NuevoMilkaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NuevoMilkaComponent]
    });
    fixture = TestBed.createComponent(NuevoMilkaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
